function mmLoadMenus() {
  if (window.mm_menu_0425172956_0) return;
  
  window.mm_menu_0425172956_0_1 = new Menu("OneData",132,16,"sans-serif, Verdana, Arial, Helvetica",11,"#5a5a5a","#000000","#dbe8f0","#F9FE8B","left","middle",3,1,500,0,0,true,false,true,7,true,true);
  mm_menu_0425172956_0_1.addMenuItem("OneData Overview","location='/products/index.shtml'");
  mm_menu_0425172956_0_1.addMenuItem("Value&nbsp;Proposition","location='/products/value_proposition.shtml'");
  mm_menu_0425172956_0_1.addMenuItem("Functions&nbsp;&amp;&nbsp;Features","location='/products/functions_features.shtml'");
  mm_menu_0425172956_0_1.addMenuItem("Technology","location='/products/technology.shtml'");
  mm_menu_0425172956_0_1.addMenuItem("How&nbsp;Is&nbsp;It&nbsp;Different?","location='/products/howisitdifferent.shtml'");
  mm_menu_0425172956_0_1.hideOnMouseOut=true;
  mm_menu_0425172956_0_1.menuBorder=0;
  mm_menu_0425172956_0_1.menuLiteBgColor='#ffffff';
  mm_menu_0425172956_0_1.menuBorderBgColor='#ffffff';
  mm_menu_0425172956_0_1.bgColor='#ffffff';
     
  window.mm_menu_0425172956_0 = new Menu("root",104,16,"sans-serif, Verdana, Arial, Helvetica",11,"#5a5a5a","#000000","#dbe8f0","#F9FE8B","left","middle",3,1,500,0,0,true,false,true,7,true,true);
  mm_menu_0425172956_0.addMenuItem("OneData","location='/products/index.shtml'");
  mm_menu_0425172956_0.addMenuItem("OneData&nbsp;Registry","location='/products/onedata_registry.shtml'");
  mm_menu_0425172956_0.hideOnMouseOut=true;
  mm_menu_0425172956_0.childMenuIcon="/images/menu/arrows.gif";
  mm_menu_0425172956_0.menuBorder=0;
  mm_menu_0425172956_0.menuLiteBgColor='#ffffff';
  mm_menu_0425172956_0.menuBorderBgColor='#ffffff';
  mm_menu_0425172956_0.bgColor='#ffffff';
  
  window.mm_menu_0425173950_1_1 = new Menu("Reference&nbsp;Data&nbsp;Management",149,16,"sans-serif, Verdana, Arial, Helvetica",11,"#5a5a5a","#000000","#dbe8f0","#F9FE8B","left","middle",3,1,500,0,0,true,false,true,7,true,true);
  mm_menu_0425173950_1_1.addMenuItem("Creation&nbsp;&amp;&nbsp;Maintenance","location='/solutions/RefData.shtml'");
  mm_menu_0425173950_1_1.addMenuItem("Problems&nbsp;We&nbsp;Address","location='/solutions/problems_we_address.shtml'");
  mm_menu_0425173950_1_1.addMenuItem("Benefits","location='/solutions/benefits.shtml'");
  mm_menu_0425173950_1_1.addMenuItem("Methodology","location='/solutions/methodology.shtml'");
  mm_menu_0425173950_1_1.hideOnMouseOut=true;
  mm_menu_0425173950_1_1.menuBorder=0;
  mm_menu_0425173950_1_1.menuLiteBgColor='#ffffff';
  mm_menu_0425173950_1_1.menuBorderBgColor='#ffffff';
  mm_menu_0425173950_1_1.bgColor='#ffffff';
     
  window.mm_menu_0425173950_1_2 = new Menu("Master&nbsp;Data&nbsp;Management",149,16,"sans-serif, Verdana, Arial, Helvetica",11,"#5a5a5a","#000000","#dbe8f0","#F9FE8B","left","middle",3,1,500,0,0,true,false,true,7,true,true);
  mm_menu_0425173950_1_2.addMenuItem("Creation&nbsp;&amp;&nbsp;Maintenance","location='/solutions/creation_maintenance.shtml'");
  mm_menu_0425173950_1_2.addMenuItem("Cleansing","location='/solutions/cleansing.shtml'");
  mm_menu_0425173950_1_2.hideOnMouseOut=true;
  mm_menu_0425173950_1_2.menuBorder=0;
  mm_menu_0425173950_1_2.menuLiteBgColor='#ffffff';
  mm_menu_0425173950_1_2.menuBorderBgColor='#ffffff';
  mm_menu_0425173950_1_2.bgColor='#ffffff';
     
  window.mm_menu_0425173950_1_1 = new Menu("Vertical/Industry Solutions",200,16,"sans-serif, Verdana, Arial, Helvetica",11,"#5a5a5a","#000000","#dbe8f0","#F9FE8B","left","middle",3,1,500,0,0,true,false,true,7,false,true);
  mm_menu_0425173950_1_1.addMenuItem("UCCnet Integration","location='/solutions/uccnet.shtml'");
  mm_menu_0425173950_1_1.addMenuItem("Pharmaceutical&nbsp;Data&nbsp;Management","location='/solutions/pharma.shtml'");
  mm_menu_0425173950_1_1.hideOnMouseOut=true;
  mm_menu_0425173950_1_1.menuBorder=0;
  mm_menu_0425173950_1_1.menuLiteBgColor='#ffffff';
  mm_menu_0425173950_1_1.menuBorderBgColor='#ffffff';
  mm_menu_0425173950_1_1.bgColor='#ffffff';
     
  window.mm_menu_0425173950_1 = new Menu("root",180,16,"sans-serif, Verdana, Arial, Helvetica",11,"#5a5a5a","#000000","#dbe8f0","#F9FE8B","left","middle",3,1,500,0,0,true,false,true,7,true,true);
  mm_menu_0425173950_1.addMenuItem("Master Data Management","location='/solutions/mdm.shtml'");
  mm_menu_0425173950_1.addMenuItem("Reference Data Management","location='/solutions/problems_we_address.shtml'");
  mm_menu_0425173950_1.addMenuItem("Hierarchy Management","location='/solutions/ohm.shtml'");
  mm_menu_0425173950_1.addMenuItem("Enterprise&nbsp;Info&nbsp;Management","location='/solutions/eim.shtml'");
  mm_menu_0425173950_1.addMenuItem("Data&nbsp;Registries","location='/solutions/data_registries.shtml'");
  mm_menu_0425173950_1.addMenuItem("OneData Anywhere","location='/solutions/onedata_anywhere.shtml'");  
  mm_menu_0425173950_1.addMenuItem(mm_menu_0425173950_1_1,"location='/solutions/uccnet.shtml'");
  mm_menu_0425173950_1.hideOnMouseOut=true;
  mm_menu_0425173950_1.childMenuIcon="/images/menu/arrows.gif";
  mm_menu_0425173950_1.menuBorder=0;
  mm_menu_0425173950_1.menuLiteBgColor='#ffffff';
  mm_menu_0425173950_1.menuBorderBgColor='#ffffff';
  mm_menu_0425173950_1.bgColor='#ffffff';
   
  window.mm_menu_0426155857_2_1 = new Menu("Consulting&nbsp;Services",115,16,"sans-serif, Verdana, Arial, Helvetica",11,"#5a5a5a","#000000","#dbe8f0","#F9FE8B","left","middle",3,1,500,0,0,true,false,true,7,false,true);
  mm_menu_0426155857_2_1.addMenuItem("Standard&nbsp;Data","location='/services/standard_data.shtml'");
  mm_menu_0426155857_2_1.addMenuItem("Syndicated&nbsp;Data","location='/services/syndicated_data.shtml'");
  mm_menu_0426155857_2_1.hideOnMouseOut=true;
  mm_menu_0426155857_2_1.menuBorder=0;
  mm_menu_0426155857_2_1.menuLiteBgColor='#ffffff';
  mm_menu_0426155857_2_1.menuBorderBgColor='#ffffff';
  mm_menu_0426155857_2_1.bgColor='#ffffff';
     
  window.mm_menu_0426155857_2 = new Menu("root",125,16,"sans-serif, Verdana, Arial, Helvetica",11,"#5a5a5a","#000000","#dbe8f0","#F9FE8B","left","middle",3,1,500,0,0,true,false,true,7,false,true);
  mm_menu_0426155857_2.addMenuItem("Support&nbsp;Services","location='/services/customer_support.shtml'");
  mm_menu_0426155857_2.addMenuItem(mm_menu_0426155857_2_1,"location='/services/consulting_services.shtml'");
  mm_menu_0426155857_2.addMenuItem("Education&nbsp;Services","location='/services/education_services.shtml'");
  mm_menu_0426155857_2.hideOnMouseOut=true;
  mm_menu_0426155857_2.childMenuIcon="/images/menu/arrows.gif";
  mm_menu_0426155857_2.menuBorder=0;
  mm_menu_0426155857_2.menuLiteBgColor='#ffffff';
  mm_menu_0426155857_2.menuBorderBgColor='#ffffff';
  mm_menu_0426155857_2.bgColor='#ffffff';
   
  window.mm_menu_0425174640_2_1 = new Menu("Success&nbsp;Stories",250,16,"sans-serif, Verdana, Arial, Helvetica",11,"#5a5a5a","#000000","#dbe8f0","#F9FE8B","left","middle",3,1,500,0,0,true,false,true,7,true,true);
  mm_menu_0425174640_2_1.addMenuItem("Product&nbsp;Data&nbsp;Cleansing","location='/customers/product_data_cleansing.shtml'");
  mm_menu_0425174640_2_1.addMenuItem("Reference&nbsp;Data&nbsp;Centralization&nbsp;&amp;&nbsp;Deployment","location='/customers/reference_data.shtml'");
  mm_menu_0425174640_2_1.addMenuItem("Enterprise&nbsp;Information&nbsp;Management","location='/customers/enterprise_information.shtml'");
  mm_menu_0425174640_2_1.addMenuItem("Client&nbsp;&amp;&nbsp;Counterparty&nbsp;Reference&nbsp;Data","location='/customers/client_counterparty.shtml'");
  mm_menu_0425174640_2_1.hideOnMouseOut=true;
  mm_menu_0425174640_2_1.menuBorder=0;
  mm_menu_0425174640_2_1.menuLiteBgColor='#ffffff';
  mm_menu_0425174640_2_1.menuBorderBgColor='#ffffff';
  mm_menu_0425174640_2_1.bgColor='#ffffff';
     
  window.mm_menu_0425174640_2 = new Menu("root",110,16,"sans-serif, Verdana, Arial, Helvetica",11,"#5a5a5a","#000000","#dbe8f0","#F9FE8B","left","middle",3,1,500,0,0,true,false,true,7,true,true);
  mm_menu_0425174640_2.addMenuItem("Customer&nbsp;List","location='/customers/index.shtml'");
  mm_menu_0425174640_2.addMenuItem(mm_menu_0425174640_2_1,"location='/customers/product_data_cleansing.shtml'");
  mm_menu_0425174640_2.addMenuItem("Customer&nbsp;Support","location='/customers/customer_support.shtml'");
  mm_menu_0425174640_2.hideOnMouseOut=true;
  mm_menu_0425174640_2.childMenuIcon="/images/menu/arrows.gif";
  mm_menu_0425174640_2.menuBorder=0;
  mm_menu_0425174640_2.menuLiteBgColor='#ffffff';
  mm_menu_0425174640_2.menuBorderBgColor='#ffffff';
  mm_menu_0425174640_2.bgColor='#ffffff';
   
  window.mm_menu_0426160306_3 = new Menu("root",102,16,"sans-serif, Verdana, Arial, Helvetica",11,"#5a5a5a","#000000","#dbe8f0","#F9FE8B","left","middle",3,1,500,0,0,true,false,true,7,true,true);
  mm_menu_0426160306_3.addMenuItem("Press&nbsp;Releases","location='/news/index.shtml'");
  mm_menu_0426160306_3.addMenuItem("Events","location='/news/events.shtml'");
  mm_menu_0426160306_3.hideOnMouseOut=true;
  mm_menu_0426160306_3.menuBorder=0;
  mm_menu_0426160306_3.menuLiteBgColor='#ffffff';
  mm_menu_0426160306_3.menuBorderBgColor='#ffffff';
  mm_menu_0426160306_3.bgColor='#ffffff';
   
  window.mm_menu_0426160432_4 = new Menu("root",102,16,"sans-serif, Verdana, Arial, Helvetica",11,"#5a5a5a","#000000","#dbe8f0","#F9FE8B","left","middle",3,1,500,0,0,true,false,true,7,true,true);
  mm_menu_0426160432_4.addMenuItem("Corporate&nbsp;Profile","location='/company/index.shtml'");
  mm_menu_0426160432_4.addMenuItem("Partners","location='/company/partners.shtml'");
  mm_menu_0426160432_4.addMenuItem("Employment","location='/company/employment.shtml'");
  mm_menu_0426160432_4.addMenuItem("Contact&nbsp;Us","location='/company/contact_us.shtml'");
  mm_menu_0426160432_4.hideOnMouseOut=true;
  mm_menu_0426160432_4.menuBorder=0;
  mm_menu_0426160432_4.menuLiteBgColor='#ffffff';
  mm_menu_0426160432_4.menuBorderBgColor='#ffffff';
  mm_menu_0426160432_4.bgColor='#ffffff';

  mm_menu_0426160432_4.writeMenus();
} // mmLoadMenus()